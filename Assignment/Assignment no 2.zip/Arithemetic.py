def Add(v1, v2):
    result = v1 + v2
    return result

def Sub(v1, v2):
    result = v1 - v2
    return result

def Mult(v1, v2):
    result = v1 * v2
    return result

def Div(v1, v2):
    result = v1 / v2
    return result
