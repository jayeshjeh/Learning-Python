def Run():
    for i in range(5):
        print("Marvellous")

def main():
    Run()

if __name__ == "__main__":
    main()