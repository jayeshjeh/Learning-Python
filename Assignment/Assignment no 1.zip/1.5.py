def Iteration():
    for i in range(10,0,-1):
        print(i)

def main():
    Iteration()

if __name__ == "__main__":
    main()